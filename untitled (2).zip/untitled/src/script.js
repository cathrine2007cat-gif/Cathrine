// Add event listener to the button

document.querySelector('button').addEventListener('click', () => {

    alert('Message sent!');

});